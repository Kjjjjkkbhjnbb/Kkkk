const { ApplicationCommandType, EmbedBuilder, PermissionsBitField } = require("discord.js");

module.exports = {
    name: "limpar",
    description: "Apagar mensagens de um canal",
    type: ApplicationCommandType.ChatInput,

    options: [
        {
            name: "quantidade",
            description: "Quantas mensagens você deseja apagar?",
            type: 4,
            required: false,
            minValue: 1,
            maxValue: 1000
        },
        {
            name: "usuario",
            description: "Usuário específico para apagar mensagens",
            type: 6,
            required: false
        },
        {
            name: "mensagem-especifica",
            description: "Mensagem específica para apagar",
            type: 3,
            required: false
        }
    ],

    run: async (client, interaction) => {
        if (!interaction.member.permissions.has(PermissionsBitField.Flags.ManageMessages)) {
            const noPermissionEmbed = new EmbedBuilder()
                .setTitle("Permissão Negada")
                .setDescription("Você não tem permissão para apagar mensagens!")
                .setColor("Red")
                .setTimestamp();

            return interaction.reply({ embeds: [noPermissionEmbed], ephemeral: true });
        }

        const quantidade = interaction.options.getInteger("quantidade");
        const usuario = interaction.options.getUser("usuario");
        const mensagemEspecifica = interaction.options.getString("mensagem-especifica");
        const canal = interaction.channel;

        try {
            if (quantidade && usuario) {
                const messages = await canal.messages.fetch({ limit: quantidade });
                const messagesToDelete = messages.filter(message => message.author.id === usuario.id);
                await Promise.all(messagesToDelete.map(message => message.delete()));
                
                const successEmbed = new EmbedBuilder()
                    .setTitle("Mensagens Apagadas")
                    .setDescription(`Foram apagadas ${messagesToDelete.size} mensagens de ${usuario.tag}!`)
                    .setColor("Green")
                    .setTimestamp();

                return interaction.reply({ embeds: [successEmbed], ephemeral: true });
            }

            if (quantidade) {
                const messages = await canal.bulkDelete(quantidade, true);
                
                const successEmbed = new EmbedBuilder()
                    .setTitle("Mensagens Apagadas")
                    .setDescription(`Foram apagadas ${messages.size} mensagens do canal!`)
                    .setColor("Green")
                    .setTimestamp();

                return interaction.reply({ embeds: [successEmbed], ephemeral: true });
            }

            if (usuario) {
                const messages = await canal.messages.fetch({ limit: 100 });
                const messagesToDelete = messages.filter(message => message.author.id === usuario.id);
                await Promise.all(messagesToDelete.map(message => message.delete()));
                
                const successEmbed = new EmbedBuilder()
                    .setTitle("Mensagens Apagadas")
                    .setDescription(`Foram apagadas mensagens de ${usuario.tag}!`)
                    .setColor("Green")
                    .setTimestamp();

                return interaction.reply({ embeds: [successEmbed], ephemeral: true });
            }

            if (mensagemEspecifica) {
                const messages = await canal.messages.fetch({ limit: 100 });
                const messagesToDelete = messages.filter(message => message.content.includes(mensagemEspecifica));
                await Promise.all(messagesToDelete.map(message => message.delete()));
                
                const successEmbed = new EmbedBuilder()
                    .setTitle("Mensagens Apagadas")
                    .setDescription(`Foram apagadas mensagens contendo "${mensagemEspecifica}"!`)
                    .setColor("Green")
                    .setTimestamp();

                return interaction.reply({ embeds: [successEmbed], ephemeral: true });
            }

            const messages = await canal.bulkDelete(100, true);
            
            const successEmbed = new EmbedBuilder()
                .setTitle("Mensagens Apagadas")
                .setDescription(`Foram apagadas ${messages.size} mensagens do canal!`)
                .setColor("Green")
                .setTimestamp();

            return interaction.reply({ embeds: [successEmbed], ephemeral: true });

        } catch (error) {
            const errorEmbed = new EmbedBuilder()
                .setTitle("Erro ao Apagar Mensagens")
                .setDescription(`Ocorreu um erro ao tentar apagar as mensagens: ${error.message}`)
                .setColor("Red")
                .setTimestamp();

            return interaction.reply({ embeds: [errorEmbed], ephemeral: true });
        }
    }
};
