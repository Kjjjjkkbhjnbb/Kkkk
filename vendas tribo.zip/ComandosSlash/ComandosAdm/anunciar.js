const { EmbedBuilder, ModalBuilder, TextInputBuilder, PermissionFlagsBits, ActionRowBuilder } = require("discord.js");
const { General, emoji } = require("../../DataBaseJson");

module.exports = {
   name: "anunciar",
   description: "[🛠️ | Moderação] Envie um anúncio.",
   
   run: async (client, interaction) => {
      if (!interaction.member.permissions.has(PermissionFlagsBits.Administrator)) {
         return interaction.reply({ content: `${emoji.get(`emojix`)} | Você não possui permissão para utilizar esse comando!`, ephemeral: true });
      }
      
      const modal = new ModalBuilder()
         .setCustomId('modalanuncio')
         .setTitle('🎉 | Anunciar');
       
      const text1 = new TextInputBuilder()
         .setCustomId('titulo')
         .setLabel('Título:')
         .setPlaceholder('Título do anúncio.')
         .setRequired(true)
         .setStyle(1);
       
      const text2 = new TextInputBuilder()
         .setCustomId('desc')
         .setLabel('Descrição:')
         .setPlaceholder('Descrição do anúncio.')
         .setRequired(true)
         .setStyle(2);
       
      const text3 = new TextInputBuilder()
         .setCustomId('content')
         .setLabel('Conteúdo: (opcional)')
         .setPlaceholder('Texto fora da Embed.')
         .setRequired(false)
         .setStyle(1);
       
      const text4 = new TextInputBuilder()
         .setCustomId('banner')
         .setLabel('Banner: (opcional)')
         .setPlaceholder('Link da Imagem para o anúncio.')
         .setRequired(false)
         .setStyle(1);
       
      const text5 = new TextInputBuilder()
         .setCustomId('cor')
         .setLabel('Cor: (opcional)')
         .setPlaceholder('Cor da Embed (hex).')
         .setRequired(false)
         .setStyle(1);
       
      modal.addComponents(
         new ActionRowBuilder().addComponents(text1),
         new ActionRowBuilder().addComponents(text2),
         new ActionRowBuilder().addComponents(text3),
         new ActionRowBuilder().addComponents(text4),
         new ActionRowBuilder().addComponents(text5)
      );
      
      interaction.showModal(modal);
      
      client.on('interactionCreate', async (interaction) => {
         if (interaction.isModalSubmit() && interaction.customId === 'modalanuncio') {
            const titulo = interaction.fields.getTextInputValue("titulo");
            const desc = interaction.fields.getTextInputValue("desc");
            const content = interaction.fields.getTextInputValue("content");
            const banner = interaction.fields.getTextInputValue("banner");
            const cor = interaction.fields.getTextInputValue("cor") || General.get(`color.padrao`);
             
            if (banner && !isValidUrl(banner)) {
               return interaction.reply({ content: `${emoji.get(`emojix`)} | Você inseriu um banner inválido!`, ephemeral: true });
            }
             
            if (cor && !isValidHexColor(cor)) {
               return interaction.reply({ content: `${emoji.get(`emojix`)} | Você inseriu uma cor inválida!`, ephemeral: true });
            }
             
            const embedAnuncio = new EmbedBuilder()
               .setTitle(titulo)
               .setDescription(desc)
               .setColor(cor)
               .setTimestamp()
               .setFooter({ text: client.user.username, iconURL: client.user.displayAvatarURL({ dynamic: true }) });

            if (banner) {
               embedAnuncio.setImage(banner);
            }
             
            try {
               await interaction.channel.send({ content: content || '', embeds: [embedAnuncio] });
               await interaction.reply({ content: `${emoji.get(`certo`)} | Anúncio enviado com sucesso!`, ephemeral: true });
            } catch (error) {
               interaction.reply({ content: `${emoji.get(`alerta`)} | Erro ao enviar o anúncio!\n${emoji.get(`emojix`)} | Erro: \`${error.message}\``, ephemeral: true });
            }
         }
      });
   }
};

function isValidUrl(url) {
   const urlRegex = /^(https?|ftp):\/\/[^\s/$.?#].[^\s]*$/;
   return urlRegex.test(url);
}

function isValidHexColor(color) {
   const hexColorRegex = /^#([0-9A-Fa-f]{6}|[0-9A-Fa-f]{3})$/;
   return hexColorRegex.test(color);
}
