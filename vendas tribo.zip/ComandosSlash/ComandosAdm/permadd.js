const { ApplicationCommandType, ApplicationCommandOptionType, EmbedBuilder } = require("discord.js");
const { perms, General, emoji } = require("../../DataBaseJson");

module.exports = {
    name: "permadd",
    description: "[🛠️|💰 Vendas Moderação] Adicionar permissão para algum usuário utilizar os comandos!",
    type: ApplicationCommandType.ChatInput,
    options: [
        {
           name: "user",
           description: "Selecione o usuário",
           type: ApplicationCommandOptionType.User,
           required: true
        }
    ],
    
    run: async (client, interaction) => {
        if (interaction.user.id !== General.get('creator')) {
            return interaction.reply({ 
                embeds: [new EmbedBuilder()
                    .setDescription(`${emoji.get(`emojix`)} | Você não possui permissão para utilizar esse comando.`)
                    .setColor("Red")
                ], 
                ephemeral: true 
            });
        }
         
        const userx = interaction.options.getUser("user");
         
        if (perms.has(userx.id)) {
            return interaction.reply({ 
                embeds: [new EmbedBuilder()
                    .setDescription(`${emoji.get(`emojix`)} | O usuário selecionado já possui permissão.`)
                    .setColor("Red")
                ], 
                ephemeral: true 
            });
        }
         
        perms.set(userx.id, userx.id);
        
        const embed = new EmbedBuilder()
            .setDescription(`${emoji.get('certo')} | Permissão concedida para o usuário ${userx} com sucesso.`)
            .setColor("Green")
            .setFooter({ text: `Comando executado por ${interaction.user.tag}`, iconURL: interaction.user.displayAvatarURL({ dynamic: true }) })
            .setTimestamp();
        
        interaction.reply({ embeds: [embed], ephemeral: true });
    }
};
