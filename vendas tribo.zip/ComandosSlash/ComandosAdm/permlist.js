const { EmbedBuilder, ActionRowBuilder, ButtonBuilder, ApplicationCommandType, ApplicationCommandOptionType } = require("discord.js");
const { perms, General, emoji } = require("../../DataBaseJson");

module.exports = {
   name: "permlist",
   description: "[🛠|💰 Vendas Moderação] Veja todos os usuários que possuem permissão no bot",
   type: ApplicationCommandType.ChatInput,
   
   run: async(client, interaction) => {
       if (interaction.user.id !== General.get('creator')) {
           return interaction.reply({
               embeds: [new EmbedBuilder()
                   .setDescription(`${emoji.get(`emojix`)} | Você não possui permissão para utilizar esse comando.`)
                   .setColor("Red")
               ],
               ephemeral: true
           });
       }
       
       const permUsers = perms.all().map(entry => `${emoji.get(`user`)} | <@${entry.ID}> - \`${entry.ID}\``).join('\n\n');
       const permCount = perms.all().length;
       
       const embed = new EmbedBuilder()
           .setTitle(`Membros com permissão - ${permCount}`)
           .setDescription(permCount === 0 ? `\`Nenhum usuário possui permissão no seu BOT.\`` : permUsers)
           .setColor(General.get(`color.padrao`))
           .setFooter({ text: `Comando solicitado por ${interaction.user.tag}`, iconURL: interaction.user.displayAvatarURL({ dynamic: true }) })
           .setTimestamp();

       interaction.reply({ embeds: [embed], ephemeral: true });
   }
};
